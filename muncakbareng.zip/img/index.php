<?php
header("location: ../index");
?>